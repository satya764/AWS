          #!bin/bash
        #   sudo apt install unzip
        #   sudo curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
        #   sudo unzip awscliv2.zip
        #   sudo ./aws/install
          yes | sudo apt update
          yes | sudo apt install apache2